#include <iostream>
#include <fstream>
#include <filesystem>
#include "Player.h"

#pragma 

// using std
using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::fstream;
using std::ios;

// while window loop
bool windowrunning = true;

// constants 
const char* BLUE = "\x1b[94m";
const char* INDENT = "\x1b[5C";
const char* RESET_COLOR = "\x1b[0m";

// global values 
int playerlength = 3;

void Readfile(Player playerarray[]);
void Menu(Player playerarray[]);

void Print(Player playerarray[])
{
	system("cls");
	cout << INDENT << "  Players:" << endl;
	for (int i = 0; i < playerlength; i++)
	{
		cout << INDENT << playerarray[i].m_score << INDENT << playerarray[i].m_name << endl;
	}
	cin.get();
	Menu(playerarray);
}

// sorting numbers using insertion sort 
void Insertionsort(Player playerarray[])
{
	int key, x;
	for (int i = 1; i < playerlength; i++)
	{
		key = playerarray[i].m_score;
		x = i - 1;

		while (x >= 0 && playerarray[x].m_score > key)
		{
			playerarray[i].m_score = playerarray[x].m_score;
			x--;
		}
		playerarray[i].m_score = key;
	}
}

// print highest scores
void Highscores(Player playerarray[])
{
	int n = sizeof(playerarray) / sizeof(playerarray[0]);
	Insertionsort(playerarray);
	Print(playerarray);
}

// sorting names by using a modified version of insertion sort
void Namesort(Player playerarray[])
{
	string key;
	int x;
	for (int i = 1; i < playerlength; i++)
	{
		key = playerarray[i].m_name;
		x = i - 1;

		if (x >= 0 && playerarray[x].m_name > key)
		{
			strcpy(playerarray[i].m_name, playerarray[x].m_name);
			x--;
		}
		playerarray[i].setname(key);
	}
	Print(playerarray);
}

// create new Player score 
void Create(Player playerarray[])
{
	int placement;
	char name[8];
	int score;
	playerlength++;

	// array declaration
	Player* newlength = new Player[playerlength];
	Player* oldlength = playerarray;
	// swapping variables 
	for (int i = 0; i < playerlength; i++)
	{
		newlength[i] = playerarray[i];
	}
	// declaring new space 
	playerarray = newlength;

	// deleting unwanted arrays 
	delete[] oldlength;

	//Name input
	cout << endl << BLUE << INDENT << "   Create:" << RESET_COLOR << endl;
	cout << endl << INDENT << "Name: ";
	cin >> name;

	// input Fail Test
	cin.clear();
	cin.ignore(cin.rdbuf()->in_avail());

	if (cin.fail())
	{
		cout << INDENT << "Try Again, Press enter to continue" << endl;
		cin.get();
		Create(playerarray);
	}

	// score input
	cout << endl << INDENT << "Score: ";
	cin >> score;

	for (int i = 0; i < playerlength; i++)
	{
		if (*playerarray[i].m_name == *name)
		{
			playerarray[i].m_score = score;
			system("cls");
			cout << playerarray[i].m_name << " score was updated." << endl;
			break;
		}
	}
	delete[] name;

	cin.get();
	Menu(playerarray);
}

// menu function
void Menu(Player playerarray[])
{
	// clears screen
	system("cls");

	// outputs Menu items
	cout << endl << BLUE << INDENT << "   HIGHSCORES" << RESET_COLOR << endl << endl;
	cout << INDENT << "1. View Highest Scores" << endl;
	cout << INDENT << "2. Create New Entry" << endl;
	cout << INDENT << "3. Sort By Name" << endl;

	// clear and prepare input
	cin.clear();
	cin.ignore(cin.rdbuf()->in_avail());

	// menu input
	int menuselect;
	cin >> menuselect;

	// input Fail Test
	cin.clear();
	cin.ignore(cin.rdbuf()->in_avail());

	if (cin.fail() || menuselect > 3 || menuselect < 1)
	{
		cout << INDENT << "Try Again, Press enter to continue" << endl;
		cin.get();
		Menu(playerarray);
	}

	if (std::cin.fail())
		Menu(playerarray);

	// menu cin result outcomes 
	if (menuselect >= 4 || menuselect <= 0)
	{
		cout << "Try Again! ";
		cin.get();
		Menu(playerarray);
	}

	if (menuselect == 1)
		Highscores(playerarray);

	if (menuselect == 2)
		Create(playerarray);

	if (menuselect == 3)
		Namesort(playerarray);

	//if (menuselect == 4)
}

// read from file on open
void readfile(Player playerarray[])
{
	fstream file;
	file.open("data.dat", ios::in | ios::binary);
	if (!file)
	{
		file.close();
		file.open("data.dat", ios::out | ios::binary);
		file.close();
		file.open("data.dat", ios::in | ios::binary);
	}
	file.seekg(0, ios::end);
	int length = file.tellp() / sizeof(Player);
	file.seekg(0, ios::beg);

}

// main function
int main()
{
	// initialise main array 
	Player* playerarray = new Player[];

	// begin by reading from file
	readfile(playerarray);

	// end main by returning a variable
	return 0;
}
