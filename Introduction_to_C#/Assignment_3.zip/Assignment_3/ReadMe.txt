Under "Release" Folder run the .exe to run the program

Where available, input numbers to navigate through the game. Note that on some menus require to input text or the names of items.


Menu:

	1. Allows the player to view the players inventory with each item listed with the players quantity
	2. Allows the player to view the stores inventory with each item listed with the stores quantity
	3. Allows the player to purchase items from the store, includes any items added by the super user 
	4. Allows the player to sell items from their own inventory, including any items added by the super user 
	5. Allows the player to search items, their quantity and value from both the player and stores inventories
	6. Allows the player to view how much they have in their wallet
	7. Allows the player to save any information [NOTE items bought and sold without saving will revert to previous information on the applications reopen
	8. Quits the application

	*Press enter to exit most menus*


The Menu has a few secret inputs to reach hidden features:

	69 | Adds $1000 to the wallet

	88224646 | Allows the Super user to create an item (up up down down left right left right, on the numpad)then follow the prompts

	9 | The delete page where the Super user can delete created items, noting that this will ERASE any data created for the object 


	
Most initial unit testing was completed and commented on a previous version of the assignment found in "Unit Testing"


BEWARE OF FILE PATH ERRORS 

Written by Oscar Smith 

