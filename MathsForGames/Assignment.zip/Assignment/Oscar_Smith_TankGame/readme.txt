Use:

W - Forward
S - Backward
D - Rotate Right 
A - Rotate Left 

E - Rotate turret right 
Q - Rotate turret left 

SPACE - Shoot turret

_______________________________________________________________

Note:

#The games .exe is located in /Release/..

#Tank Game code is located in /TankGame/..

#Unit Test and Math Classes are also in /TankGame/UnitTest_And_MathClasses..

#Projectiles collide with the boundaries of the window